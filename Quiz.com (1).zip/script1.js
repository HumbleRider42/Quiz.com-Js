const questions = {
    Math: [
        { question: "What is 2 + 2?", options: ["3", "4", "5", "6"], answer: "4" },
        { question: "What is 5 * 6?", options: ["30", "25", "20", "35"], answer: "30" },
        { question: "What is 12 / 4?", options: ["2", "3", "4", "6"], answer: "3" },
        { question: "What is 7 - 3?", options: ["3", "4", "5", "6"], answer: "4" },
        { question: "What is 9 + 1?", options: ["10", "11", "12", "9"], answer: "10" }
    ],
    Science: [
        { question: "What is the chemical symbol for water?", options: ["H2O", "CO2", "O2", "H2"], answer: "H2O" },
        { question: "What planet is known as the Red Planet?", options: ["Mars", "Earth", "Jupiter", "Venus"], answer: "Mars" },
        { question: "What gas do plants absorb from the atmosphere?", options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"], answer: "Carbon Dioxide" },
        { question: "What is the powerhouse of the cell?", options: ["Nucleus", "Ribosome", "Mitochondria", "Chloroplast"], answer: "Mitochondria" },
        { question: "What is the boiling point of water?", options: ["100°C", "90°C", "80°C", "70°C"], answer: "100°C" }
    ],
    Sst: [
        { question: "Who was the first President of the United States?", options: ["George Washington", "Thomas Jefferson", "Abraham Lincoln", "John Adams"], answer: "George Washington" },
        { question: "In which year did World War II end?", options: ["1945", "1939", "1941", "1943"], answer: "1945" },
        { question: "What is the capital of France?", options: ["Paris", "Berlin", "Madrid", "Rome"], answer: "Paris" },
        { question: "Who discovered America?", options: ["Christopher Columbus", "Vasco da Gama", "Ferdinand Magellan", "Marco Polo"], answer: "Christopher Columbus" },
        { question: "What is the largest continent?", options: ["Asia", "Africa", "Europe", "North America"], answer: "Asia" }
    ],
    English: [
        { question: "What is the synonym of 'happy'?", options: ["Sad", "Joyful", "Angry", "Disappointed"], answer: "Joyful" },
        { question: "What is the antonym of 'difficult'?", options: ["Easy", "Hard", "Complicated", "Challenging"], answer: "Easy" },
        { question: "Which word is a noun?", options: ["Run", "Quickly", "Happiness", "Blue"], answer: "Happiness" },
        { question: "Which is a verb?", options: ["Happy", "Run", "Blue", "Joy"], answer: "Run" },
        { question: "What is the plural form of 'mouse'?", options: ["Mouses", "Mouse", "Mice", "Meese"], answer: "Mice" }
    ],
    Computer: [
        { question: "What does CPU stand for?", options: ["Central Processing Unit", "Central Process Unit", "Computer Personal Unit", "Central Processor Unit"], answer: "Central Processing Unit" },
        { question: "What is the main page of a website called?", options: ["Home Page", "Index", "Directory", "Main Page"], answer: "Home Page" },
        { question: "Which language is used for web development?", options: ["HTML", "Python", "Java", "C++"], answer: "HTML" },
        { question: "What does RAM stand for?", options: ["Random Access Memory", "Read Access Memory", "Run Access Memory", "Random Act Memory"], answer: "Random Access Memory" },
        { question: "Which is an example of an input device?", options: ["Keyboard", "Monitor", "Printer", "Speaker"], answer: "Keyboard" }
    ]
};

let currentSubject;
let currentQuestionIndex = 0;
let score = 0;

window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const subject = urlParams.get('subject');
    currentSubject = questions[subject];
    displayQuestion();
};

function displayQuestion() {
    if (currentQuestionIndex >= currentSubject.length) {
        displayResult();
        return;
    }

    const questionData = currentSubject[currentQuestionIndex];
    document.getElementById('question').innerText = questionData.question;

    const optionsList = document.getElementById('options');
    optionsList.innerHTML = ''; 
    questionData.options.forEach(option => {
        const li = document.createElement('li');
        const radio = document.createElement('input');
        radio.type = 'radio';
        radio.name = 'option';
        radio.value = option;
        li.appendChild(radio);
        li.appendChild(document.createTextNode(option));
        optionsList.appendChild(li);
    });
}

function Answer() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    const questions = 5;
    if (selectedOption && selectedOption.value === currentSubject[currentQuestionIndex].answer) {
        score += 1+"  /  "+questions;
    }

    currentQuestionIndex += 1;
    displayQuestion();
    return false; 
}

function displayResult() {
    document.getElementById('score').innerText = score;
    document.getElementById('result').style.display = 'block';
    document.getElementById('Form').style.display = 'none';
}