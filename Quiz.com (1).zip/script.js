// This is the programme to login the user 
function saveUsername() {
    var username = document.loginform.username.value;
    localStorage.setItem('username', username);
    window.location.href = 'dashboard.html';
}
function dashboard() {
    var userName = document.loginform.username.value;
    var passWord = document.loginform.password.value;
    if (userName == null || userName == "") {
        alert("Please Enter the username")
        return false;
    }
    else if (passWord.length < 5) {
        alert("Please enter the password greater than 5 characters")
        return false;
    }
    else {
        localStorage.setItem('username', userName);
        localStorage.setItem('password', passWord);
        window.location.href = 'dashboard.html';
        return false;
    }
}